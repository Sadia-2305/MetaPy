"""MetaPy research software package."""
