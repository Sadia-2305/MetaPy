"""MetaPy effect-size methods."""
